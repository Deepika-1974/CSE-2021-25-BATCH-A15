from flask import Flask, render_template, request, redirect, url_for, flash, session
import tensorflow as tf
from tensorflow.keras.preprocessing import image
import numpy as np
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for session handling

# Dummy user database (for demonstration purposes)
users = {}

# Load the AI model for classification
model_path = "static/CNN.h5"  # Ensure CNN.h5 is inside the 'static' folder
if os.path.exists(model_path):
    model = tf.keras.models.load_model(model_path)
else:
    model = None

# Define class names (update based on your dataset)
class_names = [
    'Aloevera', 'Amla', 'Arive-Dantu', 'Basale', 'Betel', 'Bhrami', 'Coriender', 'Crape_Jasmine', 'Curry',
    'Drumstick', 'Fenugreek', 'Guava', 'Henna', 'Hibiscus', 'Honge', 'Indian_Beech', 'Indian_Mustard', 'Insulin',
    'Jackfruit', 'Jamaica_Cherry-Gasagase', 'Jamun', 'Jasmine', 'Karanda', 'Lemon', 'Mango', 'Marigold',
    'Mexican_Mint', 'Mint', 'Neem', 'Oleander', 'Palak(Spinach)', 'Papaya', 'Parijata', 'Peepal', 'Pomegranate',
    'Rasna', 'Rose', 'Rose_apple', 'Roxburgh_fig', 'Sandalwood', 'Seethapala', 'Tamarind', 'Tulsi', 'Turmeric', 'Ashoka'
]

# Medicinal Information Dictionary
leaf_info = {
    'Aloevera': ('Aloe barbadensis miller', 'Heals wounds, improves digestion, boosts skin health, enhances immunity'),
    'Amla': ('Phyllanthus emblica', 'Boosts immunity, improves digestion, enhances hair growth, supports liver function'),
    'Arive-Dantu': ('Achyranthes aspera', 'Used for wound healing, diabetes management, joint health, digestion aid'),
    'Basale': ('Basella alba', 'Rich in iron, aids digestion, beneficial for eye health, strengthens hair'),
    'Betel': ('Piper betle', 'Improves digestion, enhances respiratory health, supports oral health, headache relief'),
    'Bhrami': ('Bacopa monnieri', 'Boosts memory, reduces stress, supports liver health, enhances hair growth'),
    'Coriender': ('Coriandrum sativum', 'Aids digestion, supports heart health, detoxifies body, regulates blood sugar'),
    'Crape_Jasmine': ('Tabernaemontana divaricata', 'Used for eye infections, pain relief, wound healing, neurological support'),
    'Curry': ('Murraya koenigii', 'Enhances digestion, supports hair growth, regulates blood sugar, improves eyesight'),
    'Drumstick': ('Moringa oleifera', 'Boosts immunity, supports bone health, regulates blood sugar, improves digestion'),
    'Fenugreek': ('Trigonella foenum-graecum', 'Controls blood sugar, aids digestion, enhances milk production, supports metabolism'),
    'Guava': ('Psidium guajava', 'Strengthens immunity, helps in diabetes management, supports heart health, improves skin glow'),
    'Henna': ('Lawsonia inermis', 'Natural hair dye, cools body, treats fungal infections, supports wound healing'),
    'Hibiscus': ('Hibiscus rosa-sinensis', 'Supports hair growth, lowers blood pressure, enhances skin glow, aids menstrual health'),
    'Honge': ('Pongamia pinnata', 'Treats skin diseases, insect repellent, relieves joint pain, supports liver detoxification'),
    'Indian_Beech': ('Pongamia pinnata', 'Used for skin diseases, joint pain relief, liver detox, hair growth'),
    'Indian_Mustard': ('Brassica juncea', 'Improves digestion, supports heart health, relieves muscle pain, enhances respiratory health'),
    'Insulin': ('Costus igneus', 'Reduces blood sugar, supports kidney function, aids digestion, boosts immunity'),
    'Jackfruit': ('Artocarpus heterophyllus', 'Rich in antioxidants, supports heart health, aids digestion, improves skin health'),
    'Jamaica_Cherry-Gasagase': ('Muntingia calabura', 'Used for pain relief, supports respiratory health, improves blood circulation'),
    'Jamun': ('Syzygium cumini', 'Controls blood sugar, supports digestion, improves heart health, enhances skin glow'),
    'Jasmine': ('Jasminum officinale', 'Used for stress relief, improves skin health, acts as a natural sedative, digestive aid'),
    'Karanda': ('Carissa carandas', 'Rich in antioxidants, supports digestion, boosts immunity, aids skin health'),
    'Lemon': ('Citrus limon', 'Boosts immunity, aids digestion, supports skin health, helps in weight management'),
    'Mango': ('Mangifera indica', 'Strengthens immune system, improves digestion, supports skin and hair health'),
    'Marigold': ('Tagetes erecta', 'Anti-inflammatory, supports wound healing, enhances skin health, repels insects'),
    'Mexican_Mint': ('Plectranthus amboinicus', 'Used for respiratory relief, aids digestion, supports immune system'),
    'Mint': ('Mentha arvensis', 'Aids digestion, relieves headaches, reduces stress, improves respiratory function'),
    'Neem': ('Azadirachta indica', 'Purifies blood, treats skin disorders, supports oral health, helps in diabetes management'),
    'Oleander': ('Nerium oleander', 'Used in traditional medicine for heart health, wound healing, and pain relief'),
    'Palak(Spinach)': ('Spinacia oleracea', 'Rich in iron, supports eye health, improves digestion, boosts immunity'),
    'Papaya': ('Carica papaya', 'Aids digestion, supports heart health, enhances skin glow, boosts immunity'),
    'Parijata': ('Nyctanthes arbor-tristis', 'Used for arthritis, supports liver detox, relieves fever and pain'),
    'Peepal': ('Ficus religiosa', 'Supports respiratory health, aids digestion, improves heart function, used in Ayurveda'),
    'Pomegranate': ('Punica granatum', 'Rich in antioxidants, supports heart health, enhances skin glow, aids digestion'),
    'Rasna': ('Pluchea lanceolata', 'Used for joint pain relief, supports respiratory health, aids digestion'),
    'Rose': ('Rosa indica', 'Supports skin health, relieves stress, used in perfumes and herbal teas'),
    'Rose_apple': ('Syzygium jambos', 'Supports digestion, boosts immunity, improves respiratory health'),
    'Roxburgh_fig': ('Ficus auriculata', 'Used for diabetes management, supports liver health, boosts immunity'),
    'Sandalwood': ('Santalum album', 'Used for skin health, cooling effect, stress relief, anti-inflammatory'),
    'Seethapala': ('Annona squamosa', 'Rich in vitamins, supports digestion, boosts immune system, aids skin health'),
    'Tamarind': ('Tamarindus indica', 'Aids digestion, supports heart health, rich in antioxidants, improves skin'),
    'Tulsi': ('Ocimum sanctum', 'Strengthens immunity, supports respiratory health, reduces stress, aids digestion'),
    'Turmeric': ('Curcuma longa', 'Powerful anti-inflammatory, boosts immunity, supports skin health, aids digestion'),
    'Ashoka': ('Saraca asoca', 'Used in Ayurveda for menstrual health, supports heart health, enhances skin complexion')
}


@app.route('/')
def home():
    return render_template('home.html', logged_in=session.get('logged_in', False))

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        flash("You must be logged in to access the dashboard.", "danger")
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            flash('Login successful!', 'success')
            session['logged_in'] = True  # Set session flag
            session.permanent = True  # Keep session active
            return redirect(url_for('dashboard'))  # Redirect to dashboard
        else:
            flash('Invalid credentials, please try again.', 'danger')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if username in users:
            flash('User already exists, try a different username.', 'danger')
        elif len(username) < 5:
            flash('Username must be at least 5 characters long.', 'danger')
        elif len(password) < 8:
            flash('Password must be at least 8 characters long.', 'danger')
        elif not any(char.isdigit() for char in password):
            flash('Password must contain at least one digit.', 'danger')
        elif not any(char.isupper() for char in password):
            flash('Password must contain at least one uppercase letter.', 'danger')
        elif password != confirm_password:
            flash('Passwords do not match.', 'danger')
        else:
            users[username] = password
            flash('Signup successful! You can now log in.', 'success')
            return redirect(url_for('login'))

    return render_template('signup.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)  # Remove session flag
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))



# 🌿 Image Prediction Route
@app.route('/predict', methods=['POST'])
def predict():
    if not session.get('logged_in'):
        flash("You must be logged in to upload images.", "danger")
        return redirect(url_for('login'))

    if 'file' not in request.files:
        flash("No file uploaded.", "danger")
        return redirect(url_for('dashboard'))

    file = request.files['file']
    if file.filename == '':
        flash("No file selected.", "danger")
        return redirect(url_for('dashboard'))

    # Save the uploaded file temporarily
    upload_folder = "static/uploads"
    os.makedirs(upload_folder, exist_ok=True)  # Ensure the folder exists
    filepath = os.path.join(upload_folder, file.filename)
    file.save(filepath)
    image_url = url_for('static', filename=f'uploads/{file.filename}')

    # Check if model exists
    if model is None:
        flash("Model not found!", "danger")
        return redirect(url_for('dashboard'))

    # Preprocess the image
    img = image.load_img(filepath, target_size=(128, 128))  # Resize for model
    img_array = image.img_to_array(img)
    img_array = tf.expand_dims(img_array, 0)  # Add batch dimension

    # Predict the class
    predictions = model.predict(img_array)
    predicted_class = class_names[np.argmax(predictions)]

    # Get plant details
    scientific_name, benefits = leaf_info.get(predicted_class, ("Unknown", "No information available"))

    return render_template('result.html', prediction=predicted_class, scientific_name=scientific_name, benefits=benefits, image_url=image_url)

if __name__ == '__main__':
    app.run(debug=True)
